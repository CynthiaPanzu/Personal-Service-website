import React from 'react';
import { ChevronDown, Sparkles } from 'lucide-react';

const Hero = () => {
  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="min-h-screen bg-gradient-to-br from-pink-50 via-blue-50 to-purple-50 flex items-center justify-center relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 text-pink-200 animate-pulse">
        <Sparkles size={24} />
      </div>
      <div className="absolute top-40 right-20 text-purple-200 animate-pulse delay-1000">
        <Sparkles size={20} />
      </div>
      <div className="absolute bottom-40 left-20 text-blue-200 animate-pulse delay-500">
        <Sparkles size={16} />
      </div>

      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div className="text-center lg:text-left">
              <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 animate-fade-in">
                Hi, I'm <span className="text-transparent bg-gradient-to-r from-pink-500 via-blue-600 to-purple-600 bg-clip-text">Cynthia</span>
              </h1>
              <div className="relative mb-8 animate-fade-in-delay-1">
                <p className="text-xl md:text-2xl text-gray-600 relative inline-block">
                  <span className="relative z-10 bg-gradient-to-r from-pink-600 via-blue-600 to-purple-600 bg-clip-text text-transparent font-semibold">
                    Software Developer & Tech Enthusiast
                  </span>
                  <div className="absolute -bottom-1 left-0 w-full h-3 bg-gradient-to-r from-pink-200 via-blue-200 to-purple-200 opacity-30 rounded-full transform -skew-x-12"></div>
                </p>
                <div className="flex justify-center lg:justify-start mt-2 space-x-1">
                  <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100"></div>
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
              <p className="text-lg text-gray-700 mb-12 max-w-2xl mx-auto lg:mx-0 animate-fade-in-delay-2">
                Passionate about building smart, user-friendly tech experiences that solve real-world problems and collaborating with others in tech. ✨
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-fade-in-delay-3">
                <button 
                  onClick={scrollToAbout}
                  className="bg-gradient-to-r from-pink-500 to-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:from-pink-600 hover:to-blue-700 transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                >
                  Learn More About Me
                </button>
                <a 
                  href="mailto:cynthiapanzu@gmail.com"
                  className="border-2 border-gradient-to-r from-pink-500 to-blue-600 text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text border-pink-400 px-8 py-3 rounded-full font-semibold hover:bg-gradient-to-r hover:from-pink-500 hover:to-blue-600 hover:text-white transition-all duration-200 transform hover:scale-105"
                >
                  Get In Touch
                </a>
              </div>
            </div>

            {/* Photo */}
            <div className="relative animate-fade-in-delay-2">
              <div className="relative mx-auto lg:mx-0 w-80 h-80 md:w-96 md:h-96">
                {/* Decorative background */}
                <div className="absolute inset-0 bg-gradient-to-br from-pink-200 via-blue-200 to-purple-200 rounded-full transform rotate-6 animate-pulse"></div>
                <div className="absolute inset-2 bg-gradient-to-br from-pink-100 via-blue-100 to-purple-100 rounded-full transform -rotate-3"></div>
                
                {/* Photo container */}
                <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-white shadow-2xl transform hover:scale-105 transition-transform duration-300">
                  <img 
                    src="/WhatsApp Image 2025-06-23 at 14.43.52.jpeg" 
                    alt="Cynthia Panzu - Software Developer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Floating elements */}
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-pink-400 rounded-full animate-bounce delay-300"></div>
                <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-blue-400 rounded-full animate-bounce delay-700"></div>
                <div className="absolute top-1/2 -right-8 w-4 h-4 bg-purple-400 rounded-full animate-bounce delay-500"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <button 
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-blue-600 hover:text-pink-600 transition-all duration-200 animate-bounce"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
};

export default Hero;