import React from 'react';
import { Mail, MessageCircle, Linkedin, Github, MapPin, Calendar } from 'lucide-react';

const Contact = () => {
  const contactMethods = [
    {
      icon: Mail,
      title: 'Email',
      value: 'cynthiapanzu@gmail.com',
      link: 'mailto:cynthiapanzu@gmail.com',
      description: 'Send me an email for detailed discussions'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      value: '+27 70 318 1991',
      link: 'https://wa.me/27703181991',
      description: 'Quick chat or voice call'
    },
    {
      icon: Linkedin,
      title: 'LinkedIn',
      value: 'Connect with me',
      link: 'https://www.linkedin.com/in/cynthia-panzu',
      description: 'Professional networking and updates'
    }
  ];

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Let's Work Together
          </h2>
          <div className="w-24 h-1 bg-blue-600 mx-auto mb-8"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to bring your project to life? I'd love to hear about your ideas and discuss how we can work together.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Get In Touch</h3>
                <p className="text-lg text-gray-700 mb-8">
                  I'm always excited to work on new projects and collaborate with fellow tech enthusiasts. Whether you have a specific project in mind or just want to connect, feel free to reach out!
                </p>
              </div>

              <div className="space-y-6">
                {contactMethods.map((method, index) => (
                  <a
                    key={index}
                    href={method.link}
                    target={method.title === 'LinkedIn' ? '_blank' : undefined}
                    rel={method.title === 'LinkedIn' ? 'noopener noreferrer' : undefined}
                    className="flex items-start p-6 bg-gray-50 rounded-xl hover:bg-blue-50 hover:border-blue-200 border border-gray-200 transition-all duration-300 transform hover:-translate-y-1"
                  >
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                      <method.icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg font-semibold text-gray-900 mb-1">
                        {method.title}
                      </h4>
                      <p className="text-blue-600 font-medium mb-2">
                        {method.value}
                      </p>
                      <p className="text-gray-600 text-sm">
                        {method.description}
                      </p>
                    </div>
                  </a>
                ))}
              </div>

              <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-blue-600 mr-3 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">Location</h4>
                    <p className="text-gray-700">Based in South Africa</p>
                    <p className="text-gray-600 text-sm mt-1">Open to remote work and collaborations</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Call to Action */}
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-6">Ready to Start Your Project?</h3>
              <p className="text-blue-100 mb-8 leading-relaxed">
                I'm currently available for new projects and collaborations. Let's discuss your ideas and create something amazing together!
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 mr-3 text-blue-200" />
                  <span className="text-blue-100">Available for new projects</span>
                </div>
                <div className="flex items-center">
                  <MessageCircle className="w-5 h-5 mr-3 text-blue-200" />
                  <span className="text-blue-100">Quick response time</span>
                </div>
                <div className="flex items-center">
                  <Github className="w-5 h-5 mr-3 text-blue-200" />
                  <span className="text-blue-100">Open source friendly</span>
                </div>
              </div>

              <div className="space-y-4">
                <a
                  href="mailto:cynthiapanzu@gmail.com?subject=Project Inquiry&body=Hi Cynthia, I'd like to discuss a project with you."
                  className="block w-full bg-white text-blue-600 text-center py-3 px-6 rounded-lg font-semibold hover:bg-blue-50 transition-all duration-200 transform hover:scale-105"
                >
                  Hire Me Now
                </a>
                <a
                  href="https://wa.me/27703181991?text=Hi Cynthia, I'd like to discuss a project with you."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full border-2 border-white text-white text-center py-3 px-6 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-all duration-200"
                >
                  Quick Chat on WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;