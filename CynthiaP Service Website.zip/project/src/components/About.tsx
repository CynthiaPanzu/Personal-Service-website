import React from 'react';
import { Code, Smartphone, Database, GitBranch, Palette, Users, Heart, Star } from 'lucide-react';

const About = () => {
  const skills = [
    { icon: Code, name: 'React & Web Development', description: 'HTML, CSS, JavaScript' },
    { icon: Smartphone, name: 'Mobile Development', description: 'Kotlin & Android' },
    { icon: Palette, name: 'UI/UX & Web Design', description: 'User-centered design' },
    { icon: Database, name: 'Database Management', description: 'SQL & RoomDB' },
    { icon: GitBranch, name: 'Version Control', description: 'Git & GitHub' }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-white via-pink-50 to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            About Me
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-blue-600 mx-auto mb-8 rounded-full"></div>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div className="space-y-6">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900">
                Software Developer & Tech Enthusiast
              </h3>
              <p className="text-lg text-gray-700 leading-relaxed">
                I'm a passionate software developer with expertise in both mobile and web development technologies. My focus is on creating innovative solutions that bridge the gap between complex technology and user-friendly experiences.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                With a strong foundation in modern development frameworks and a keen eye for design, I specialize in building applications that not only solve problems but also provide exceptional user experiences across all platforms.
              </p>
              <div className="bg-gradient-to-r from-pink-50 to-blue-50 p-6 rounded-2xl border border-pink-200">
                <div className="flex items-start">
                  <Heart className="w-6 h-6 text-pink-500 mr-3 mt-1 flex-shrink-0" />
                  <p className="text-lg text-gray-800 font-medium italic">
                    "I'm passionate about building smart, user-friendly tech experiences that solve real-world problems and collaborating with others in tech."
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="w-full h-96 bg-gradient-to-br from-pink-400 via-blue-400 to-purple-500 rounded-2xl shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-300"></div>
              <div className="absolute inset-0 bg-white rounded-2xl shadow-xl flex items-center justify-center transform -rotate-3 hover:rotate-0 transition-transform duration-300">
                <div className="text-center p-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-pink-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Star className="w-12 h-12 text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text" fill="currentColor" />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-2">Always Learning</h4>
                  <p className="text-gray-600">Staying curious and embracing new technologies</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-2xl shadow-lg border border-pink-100 hover:shadow-xl hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-2 hover:bg-gradient-to-br hover:from-pink-50 hover:to-blue-50"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-pink-100 to-blue-100 rounded-xl flex items-center justify-center mb-4">
                  <skill.icon className="w-6 h-6 text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">
                  {skill.name}
                </h4>
                <p className="text-gray-600 text-sm">
                  {skill.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;