import React, { useState } from 'react';
import { Globe, Palette, MessageSquare, Code, Smartphone, Settings, X } from 'lucide-react';

const Services = () => {
  const [selectedService, setSelectedService] = useState(null);

  const services = [
    {
      icon: Code,
      title: 'Development Services',
      description: 'Build modern digital experiences across web and mobile.',
      features: ['Web & Full Stack Development', 'Android App Development', 'API & Database Integration'],
      details: {
        overview: 'I provide comprehensive development services covering the full spectrum of modern digital solutions. From responsive web applications to native Android apps, I build robust, scalable solutions that meet your business needs.',
        technologies: ['React', 'Kotlin', 'Node.js', 'Express', 'MongoDB', 'PostgreSQL', 'REST APIs', 'Android Studio'],
        process: [
          'Requirements analysis and technical planning',
          'System architecture and database design',
          'Frontend and backend development',
          'API integration and testing',
          'Deployment and performance optimization'
        ],
        timeline: '4-16 weeks depending on project complexity'
      }
    },
    {
      icon: Palette,
      title: 'Design Services',
      description: 'Beautiful, user-focused interfaces and brand identity.',
      features: ['UI/UX Design', 'Web Design', 'Interactive Prototypes'],
      details: {
        overview: 'I create stunning, user-centered designs that not only look beautiful but also provide intuitive experiences. From wireframes to high-fidelity prototypes, I ensure your digital products engage and delight users.',
        technologies: ['Figma', 'Adobe Creative Suite', 'Sketch', 'InVision', 'Prototyping Tools', 'User Testing Platforms'],
        process: [
          'User research and persona development',
          'Information architecture and wireframing',
          'Visual design and brand integration',
          'Interactive prototype creation',
          'User testing and design iteration'
        ],
        timeline: '2-8 weeks for complete design projects'
      }
    },
    {
      icon: MessageSquare,
      title: 'Consulting & Strategy',
      description: 'Guidance to help plan and build smarter.',
      features: ['Tech & Stack Recommendations', 'Project Planning', 'Development Best Practices'],
      details: {
        overview: 'Get expert guidance on your technology decisions and project strategy. I help businesses and individuals make informed choices about their tech investments and development approaches.',
        technologies: ['Various Tech Stacks', 'Project Management Tools', 'Analysis Frameworks', 'Best Practice Guidelines'],
        process: [
          'Current system and requirements analysis',
          'Technology stack evaluation and recommendations',
          'Project roadmap and milestone planning',
          'Risk assessment and mitigation strategies',
          'Ongoing consultation and support'
        ],
        timeline: 'Flexible - from single sessions to ongoing partnerships'
      }
    }
  ];

  const openModal = (service) => {
    setSelectedService(service);
  };

  const closeModal = () => {
    setSelectedService(null);
  };

  return (
    <section id="services" className="py-20 bg-gradient-to-br from-gray-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Services
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-pink-500 to-blue-600 mx-auto mb-8 rounded-full"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            I offer comprehensive development services to bring your digital ideas to life
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-pink-100 hover:border-blue-200"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-pink-100 to-blue-100 rounded-2xl flex items-center justify-center mb-6">
                  <service.icon className="w-8 h-8 text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text" />
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {service.title}
                </h3>
                
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-2 mb-8">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-gray-700">
                      <div className="w-2 h-2 bg-gradient-to-r from-pink-500 to-blue-600 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="pt-4 border-t border-gray-100">
                  <button 
                    onClick={() => openModal(service)}
                    className="w-full text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text font-semibold hover:from-pink-600 hover:to-blue-700 transition-all duration-200 inline-flex items-center justify-center"
                  >
                    Get Started
                    <span className="ml-2">→</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal */}
        {selectedService && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-pink-100 to-blue-100 rounded-2xl flex items-center justify-center mr-4">
                      <selectedService.icon className="w-8 h-8 text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">{selectedService.title}</h3>
                      <p className="text-gray-600">{selectedService.description}</p>
                    </div>
                  </div>
                  <button 
                    onClick={closeModal}
                    className="text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    <X size={24} />
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Overview</h4>
                    <p className="text-gray-700 mb-6">{selectedService.details.overview}</p>

                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Technologies Used</h4>
                    <div className="flex flex-wrap gap-2 mb-6">
                      {selectedService.details.technologies.map((tech, index) => (
                        <span key={index} className="bg-gradient-to-r from-pink-100 to-blue-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Process</h4>
                    <ul className="space-y-2 mb-6">
                      {selectedService.details.process.map((step, index) => (
                        <li key={index} className="flex items-start text-gray-700 text-sm">
                          <span className="bg-gradient-to-r from-pink-500 to-blue-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs mr-3 mt-0.5 flex-shrink-0">
                            {index + 1}
                          </span>
                          {step}
                        </li>
                      ))}
                    </ul>

                    <div className="bg-gradient-to-r from-pink-50 to-blue-50 p-4 rounded-xl">
                      <div className="mb-3">
                        <span className="font-semibold text-gray-900">Timeline: </span>
                        <span className="text-gray-700">{selectedService.details.timeline}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 flex flex-col sm:flex-row gap-4">
                  <a 
                    href={`mailto:cynthiapanzu@gmail.com?subject=Service Inquiry - ${selectedService.title}&body=Hi Cynthia, I'm interested in your ${selectedService.title} service. I'd like to discuss my project requirements.`}
                    className="flex-1 bg-gradient-to-r from-pink-500 to-blue-600 text-white text-center py-3 px-6 rounded-lg font-semibold hover:from-pink-600 hover:to-blue-700 transition-all duration-200"
                  >
                    Start Project
                  </a>
                  <a 
                    href={`https://wa.me/27703181991?text=Hi Cynthia, I'm interested in your ${selectedService.title} service. Can we discuss my project?`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 border-2 border-pink-400 text-transparent bg-gradient-to-r from-pink-500 to-blue-600 bg-clip-text text-center py-3 px-6 rounded-lg font-semibold hover:bg-gradient-to-r hover:from-pink-500 hover:to-blue-600 hover:text-white transition-all duration-200"
                  >
                    Quick Chat
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Services;